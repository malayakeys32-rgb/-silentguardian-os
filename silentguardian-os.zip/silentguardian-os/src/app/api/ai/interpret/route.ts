import { NextResponse } from "next/server";

/**
 * Stub endpoint for an AI companion that can interpret a symptom check-in
 * in plain language. Plug in your own Anthropic/OpenAI API key server-side
 * (e.g. via process.env.ANTHROPIC_API_KEY) and call the model here.
 *
 * This stub intentionally does NOT provide medical diagnoses. It should
 * only ever return supportive, plain-language framing plus a reminder to
 * contact a real care team or emergency services for anything urgent.
 */
export async function POST(req: Request) {
  const body = await req.json().catch(() => null);

  if (!body) {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const { riskLevel } = body as { riskLevel?: string };

  const message =
    riskLevel === "DANGER"
      ? "Your recent check-in shows a high-risk pattern. Please contact your care team now, or call 911 if this feels like an emergency."
      : riskLevel === "WARN"
      ? "Your recent check-in shows some concerning signs. Consider reaching out to your care team to talk it through."
      : "Your recent check-in looks stable. Keep checking in regularly so patterns are easy to spot.";

  return NextResponse.json({ message });
}
