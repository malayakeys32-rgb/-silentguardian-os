import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getOrCreateDevice, getDeviceIdFromRequest } from "@/lib/device";

const AlertSchema = z.object({
  checkInId: z.string().optional(),
  riskScore: z.number(),
  riskLevel: z.enum(["LOW", "WARN", "DANGER"]),
  channel: z.enum(["SILENT", "MANUAL"]).default("MANUAL")
});

export async function GET(req: Request) {
  const deviceId = getDeviceIdFromRequest(req);
  const device = await getOrCreateDevice(deviceId);

  const alerts = await prisma.alert.findMany({
    where: { userDeviceId: device.id },
    orderBy: { createdAt: "desc" },
    take: 50
  });

  return NextResponse.json(alerts);
}

export async function POST(req: Request) {
  const deviceId = getDeviceIdFromRequest(req);
  const device = await getOrCreateDevice(deviceId);

  const body = await req.json();
  const parsed = AlertSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid alert payload", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const alert = await prisma.alert.create({
    data: {
      userDeviceId: device.id,
      checkInId: parsed.data.checkInId,
      riskScore: parsed.data.riskScore,
      riskLevel: parsed.data.riskLevel,
      channel: parsed.data.channel,
      status: "TRIGGERED"
    }
  });

  return NextResponse.json(alert, { status: 201 });
}
