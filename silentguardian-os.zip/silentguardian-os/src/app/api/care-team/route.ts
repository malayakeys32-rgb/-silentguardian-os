import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getOrCreateDevice, getDeviceIdFromRequest } from "@/lib/device";

const CareContactSchema = z.object({
  label: z.string().min(1),
  phone: z.string().min(1),
  notes: z.string().optional()
});

export async function GET(req: Request) {
  const deviceId = getDeviceIdFromRequest(req);
  const device = await getOrCreateDevice(deviceId);

  const careTeam = await prisma.careContact.findMany({
    where: { userDeviceId: device.id },
    orderBy: { createdAt: "asc" }
  });

  return NextResponse.json(careTeam);
}

export async function POST(req: Request) {
  const deviceId = getDeviceIdFromRequest(req);
  const device = await getOrCreateDevice(deviceId);

  const body = await req.json();
  const parsed = CareContactSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid care contact payload", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const careContact = await prisma.careContact.create({
    data: {
      userDeviceId: device.id,
      ...parsed.data
    }
  });

  return NextResponse.json(careContact, { status: 201 });
}
