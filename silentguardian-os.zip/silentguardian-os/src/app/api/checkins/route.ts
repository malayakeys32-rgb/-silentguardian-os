import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { computeRisk } from "@/lib/riskEngine";
import { getOrCreateDevice, getDeviceIdFromRequest } from "@/lib/device";

const CheckInSchema = z.object({
  shortnessOfBreath: z.number().min(0).max(3),
  fatigueLevel: z.number().min(0).max(3),
  canLieFlat: z.boolean(),
  coughWorse: z.boolean(),
  nearFaint: z.boolean(),
  chestPressure: z.boolean(),
  usedSubstances: z.boolean()
});

export async function GET(req: Request) {
  const deviceId = getDeviceIdFromRequest(req);
  const device = await getOrCreateDevice(deviceId);

  const checkIns = await prisma.checkIn.findMany({
    where: { userDeviceId: device.id },
    orderBy: { createdAt: "desc" },
    take: 50
  });

  return NextResponse.json(checkIns);
}

export async function POST(req: Request) {
  const deviceId = getDeviceIdFromRequest(req);
  const device = await getOrCreateDevice(deviceId);

  const body = await req.json();
  const parsed = CheckInSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid check-in payload", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const input = parsed.data;
  const { score, level } = computeRisk(input);

  const checkIn = await prisma.checkIn.create({
    data: {
      userDeviceId: device.id,
      ...input,
      riskScore: score,
      riskLevel: level
    }
  });

  // Auto-create a silent alert if risk is high enough.
  if (level === "DANGER") {
    await prisma.alert.create({
      data: {
        userDeviceId: device.id,
        checkInId: checkIn.id,
        riskScore: score,
        riskLevel: level,
        status: "TRIGGERED",
        channel: "SILENT"
      }
    });
  }

  return NextResponse.json(checkIn, { status: 201 });
}
