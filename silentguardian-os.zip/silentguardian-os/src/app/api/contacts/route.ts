import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getOrCreateDevice, getDeviceIdFromRequest } from "@/lib/device";

const ContactSchema = z.object({
  name: z.string().min(1),
  phone: z.string().min(1),
  relationship: z.string().min(1),
  canReceiveSilent: z.boolean().default(true)
});

export async function GET(req: Request) {
  const deviceId = getDeviceIdFromRequest(req);
  const device = await getOrCreateDevice(deviceId);

  const contacts = await prisma.contact.findMany({
    where: { userDeviceId: device.id },
    orderBy: { createdAt: "asc" }
  });

  return NextResponse.json(contacts);
}

export async function POST(req: Request) {
  const deviceId = getDeviceIdFromRequest(req);
  const device = await getOrCreateDevice(deviceId);

  const body = await req.json();
  const parsed = ContactSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid contact payload", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const contact = await prisma.contact.create({
    data: {
      userDeviceId: device.id,
      ...parsed.data
    }
  });

  return NextResponse.json(contact, { status: 201 });
}
