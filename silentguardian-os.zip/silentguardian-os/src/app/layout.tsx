import "./globals.css";
import type { ReactNode } from "react";

export const metadata = {
  title: "SilentGuardianOS",
  description: "Emergency-aware companion for heart failure & transplant patients."
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-sgBg text-white">
        <div className="max-w-5xl mx-auto py-6 px-4">
          <header className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-xl font-semibold tracking-tight">
                SilentGuardianOS
              </h1>
              <p className="text-xs text-sgMuted">
                Silent guardian for high-risk hearts.
              </p>
            </div>
          </header>
          {children}
        </div>
      </body>
    </html>
  );
}
