import Link from "next/link";
import { NetworkForm } from "@/components/network-form";

export default function NetworkPage() {
  return (
    <main className="space-y-4">
      <nav className="flex gap-2 text-xs">
        <Link href="/check-in" className="px-3 py-1 rounded bg-sgCard/40">
          Symptom Check-In
        </Link>
        <Link href="/network" className="px-3 py-1 rounded bg-sgCard">
          My Network
        </Link>
        <Link href="/alerts" className="px-3 py-1 rounded bg-sgCard/40">
          Alerts
        </Link>
      </nav>
      <NetworkForm />
    </main>
  );
}
