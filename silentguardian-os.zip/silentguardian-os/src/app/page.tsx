import Link from "next/link";

export default function HomePage() {
  return (
    <main className="space-y-4">
      <nav className="flex gap-2 text-sm">
        <Link href="/check-in" className="px-3 py-1 rounded bg-sgCard">
          Symptom Check-In
        </Link>
        <Link href="/network" className="px-3 py-1 rounded bg-sgCard">
          My Network
        </Link>
        <Link href="/alerts" className="px-3 py-1 rounded bg-sgCard">
          Alerts
        </Link>
      </nav>
      <p className="text-sm text-sgMuted">
        Choose a tab to begin. This is your quiet, always-on emergency OS.
      </p>
    </main>
  );
}
