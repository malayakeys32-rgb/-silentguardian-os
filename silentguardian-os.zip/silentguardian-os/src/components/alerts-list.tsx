"use client";

import { useEffect, useState } from "react";
import { Card } from "./ui/card";

type Alert = {
  id: string;
  createdAt: string;
  riskScore: number;
  riskLevel: string;
  status: string;
  channel: string;
};

export function AlertsList() {
  const [alerts, setAlerts] = useState<Alert[]>([]);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/alerts");
        if (res.ok) setAlerts(await res.json());
      } catch (err) {
        console.error("Failed to load alerts", err);
      }
    })();
  }, []);

  return (
    <Card className="space-y-2">
      <div>
        <p className="text-xs text-sgMuted uppercase tracking-wide">
          Alert History
        </p>
      </div>
      {alerts.length === 0 && (
        <p className="text-xs text-sgMuted">
          No alerts triggered yet. Run a check-in, then use the silent alert
          panel.
        </p>
      )}
      <div className="space-y-2 text-xs">
        {alerts.map((a) => (
          <div
            key={a.id}
            className="flex justify-between items-center border-b border-white/5 pb-1 last:border-0"
          >
            <div>
              <p className="font-medium">
                {a.riskLevel} • {a.riskScore} pts
              </p>
              <p className="text-sgMuted">
                {new Date(a.createdAt).toLocaleString()} • {a.channel}
              </p>
            </div>
            <span className="text-[10px] text-sgMuted">{a.status}</span>
          </div>
        ))}
      </div>
    </Card>
  );
}
