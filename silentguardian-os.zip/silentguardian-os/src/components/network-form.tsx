"use client";

import { useEffect, useState } from "react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";

type Contact = {
  id: string;
  name: string;
  phone: string;
  relationship: string;
  canReceiveSilent: boolean;
};

type CareContact = {
  id: string;
  label: string;
  phone: string;
  notes?: string | null;
};

export function NetworkForm() {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [careContacts, setCareContacts] = useState<CareContact[]>([]);

  const [newContact, setNewContact] = useState({
    name: "",
    phone: "",
    relationship: "",
    canReceiveSilent: true
  });

  const [newCare, setNewCare] = useState({
    label: "",
    phone: "",
    notes: ""
  });

  useEffect(() => {
    (async () => {
      try {
        const [cRes, ctRes] = await Promise.all([
          fetch("/api/contacts"),
          fetch("/api/care-team")
        ]);
        if (cRes.ok) setContacts(await cRes.json());
        if (ctRes.ok) setCareContacts(await ctRes.json());
      } catch (err) {
        console.error("Failed to load network", err);
      }
    })();
  }, []);

  async function addContact() {
    const res = await fetch("/api/contacts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newContact)
    });
    if (res.ok) {
      const created = await res.json();
      setContacts((prev) => [...prev, created]);
      setNewContact({
        name: "",
        phone: "",
        relationship: "",
        canReceiveSilent: true
      });
    }
  }

  async function addCareContact() {
    const res = await fetch("/api/care-team", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newCare)
    });
    if (res.ok) {
      const created = await res.json();
      setCareContacts((prev) => [...prev, created]);
      setNewCare({ label: "", phone: "", notes: "" });
    }
  }

  return (
    <div className="grid md:grid-cols-2 gap-4">
      <Card className="space-y-3">
        <div>
          <p className="text-xs text-sgMuted uppercase tracking-wide">
            Trusted Contacts
          </p>
          <p className="text-xs text-sgMuted">
            People who will receive a silent alert if triggered.
          </p>
        </div>

        <div className="space-y-2 text-xs">
          <input
            className="w-full rounded bg-black/30 px-2 py-1 text-xs"
            placeholder="Name"
            value={newContact.name}
            onChange={(e) =>
              setNewContact((s) => ({ ...s, name: e.target.value }))
            }
          />
          <input
            className="w-full rounded bg-black/30 px-2 py-1 text-xs"
            placeholder="Phone number"
            value={newContact.phone}
            onChange={(e) =>
              setNewContact((s) => ({ ...s, phone: e.target.value }))
            }
          />
          <input
            className="w-full rounded bg-black/30 px-2 py-1 text-xs"
            placeholder="Relationship (sister, friend)"
            value={newContact.relationship}
            onChange={(e) =>
              setNewContact((s) => ({ ...s, relationship: e.target.value }))
            }
          />
          <label className="flex items-center gap-2 text-xs">
            <input
              type="checkbox"
              checked={newContact.canReceiveSilent}
              onChange={(e) =>
                setNewContact((s) => ({
                  ...s,
                  canReceiveSilent: e.target.checked
                }))
              }
            />
            <span>Can receive silent alerts</span>
          </label>
          <Button className="bg-sky-500 hover:bg-sky-400" onClick={addContact}>
            + Add Contact
          </Button>
        </div>

        <div className="border-t border-white/5 pt-2 space-y-1 text-xs">
          {contacts.length === 0 && (
            <p className="text-sgMuted">
              No contacts yet. Add at least one person you trust.
            </p>
          )}
          {contacts.map((c) => (
            <div
              key={c.id}
              className="flex justify-between items-center text-xs"
            >
              <div>
                <p className="font-medium">{c.name}</p>
                <p className="text-sgMuted">
                  {c.relationship} • {c.phone}
                </p>
              </div>
              {c.canReceiveSilent && (
                <span className="text-[10px] text-sgAccent">
                  Silent alerts enabled
                </span>
              )}
            </div>
          ))}
        </div>
      </Card>

      <Card className="space-y-3">
        <div>
          <p className="text-xs text-sgMuted uppercase tracking-wide">
            Care Team
          </p>
          <p className="text-xs text-sgMuted">
            Add your transplant center, cardiologist, or on-call nurse.
          </p>
        </div>

        <div className="space-y-2 text-xs">
          <input
            className="w-full rounded bg-black/30 px-2 py-1 text-xs"
            placeholder="Label (e.g. UCSF Transplant)"
            value={newCare.label}
            onChange={(e) =>
              setNewCare((s) => ({ ...s, label: e.target.value }))
            }
          />
          <input
            className="w-full rounded bg-black/30 px-2 py-1 text-xs"
            placeholder="Phone number"
            value={newCare.phone}
            onChange={(e) =>
              setNewCare((s) => ({ ...s, phone: e.target.value }))
            }
          />
          <textarea
            className="w-full rounded bg-black/30 px-2 py-1 text-xs"
            placeholder="Notes (hours, ask for Dr. X…)"
            value={newCare.notes}
            onChange={(e) =>
              setNewCare((s) => ({ ...s, notes: e.target.value }))
            }
          />
          <Button
            className="bg-purple-500 hover:bg-purple-400"
            onClick={addCareContact}
          >
            + Add Care Contact
          </Button>
        </div>

        <div className="border-t border-white/5 pt-2 space-y-1 text-xs">
          {careContacts.length === 0 && (
            <p className="text-sgMuted">
              Add your transplant center, cardiologist, or on-call nurse.
            </p>
          )}
          {careContacts.map((c) => (
            <div key={c.id}>
              <p className="font-medium">{c.label}</p>
              <p className="text-sgMuted">
                {c.phone}
                {c.notes ? ` • ${c.notes}` : ""}
              </p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
