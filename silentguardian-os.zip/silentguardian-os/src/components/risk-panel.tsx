import { Card } from "./ui/card";
import { riskLabel } from "@/lib/riskEngine";

export function RiskPanel({
  score,
  level
}: {
  score: number;
  level: "LOW" | "WARN" | "DANGER";
}) {
  const color =
    level === "DANGER"
      ? "text-sgDanger"
      : level === "WARN"
      ? "text-yellow-400"
      : "text-sgAccent";

  return (
    <Card className="space-y-2">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs text-sgMuted uppercase tracking-wide">
            Current Risk
          </p>
          <p className={`text-lg font-semibold ${color}`}>
            {score} points • {level}
          </p>
        </div>
      </div>
      <p className="text-xs text-sgMuted">{riskLabel(level)}</p>
      <p className="text-[10px] text-sgMuted">
        This is not a diagnosis. It helps you notice patterns and move sooner if
        something feels wrong.
      </p>
      <p className="text-[10px] text-sgDanger">
        Emergency: Call 911 • 988 (crisis line)
      </p>
    </Card>
  );
}
