"use client";

import { useState } from "react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Slider } from "./ui/slider";
import { RiskPanel } from "./risk-panel";
import { computeRisk } from "@/lib/riskEngine";

export function SymptomCheckInForm() {
  const [shortnessOfBreath, setSob] = useState(0);
  const [fatigueLevel, setFatigue] = useState(0);
  const [canLieFlat, setCanLieFlat] = useState(true);
  const [coughWorse, setCoughWorse] = useState(false);
  const [nearFaint, setNearFaint] = useState(false);
  const [chestPressure, setChestPressure] = useState(false);
  const [usedSubstances, setUsedSubstances] = useState(false);

  const [submitting, setSubmitting] = useState(false);
  const [risk, setRisk] = useState<{
    score: number;
    level: "LOW" | "WARN" | "DANGER";
  } | null>(null);

  async function handleSubmit() {
    setSubmitting(true);
    const payload = {
      shortnessOfBreath,
      fatigueLevel,
      canLieFlat,
      coughWorse,
      nearFaint,
      chestPressure,
      usedSubstances
    };

    const localRisk = computeRisk(payload);
    setRisk(localRisk);

    try {
      const res = await fetch("/api/checkins", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        console.error("Failed to save check-in");
      }
    } catch (err) {
      console.error("Network error saving check-in", err);
    }

    setSubmitting(false);
  }

  return (
    <div className="grid md:grid-cols-[2fr,1fr] gap-4">
      <Card className="space-y-4">
        <div>
          <p className="text-xs text-sgMuted uppercase tracking-wide">
            Symptom Check-In
          </p>
          <h2 className="text-sm font-semibold">
            How are you feeling right now?
          </h2>
        </div>

        <div className="space-y-3">
          <Slider
            label="Shortness of breath"
            value={shortnessOfBreath}
            onChange={setSob}
          />
          <Slider
            label="Fatigue level"
            value={fatigueLevel}
            onChange={setFatigue}
          />

          <div className="space-y-1 text-xs">
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={canLieFlat}
                onChange={(e) => setCanLieFlat(e.target.checked)}
              />
              <span>Can lie flat without worsening</span>
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={coughWorse}
                onChange={(e) => setCoughWorse(e.target.checked)}
              />
              <span>Cough is worse than usual</span>
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={nearFaint}
                onChange={(e) => setNearFaint(e.target.checked)}
              />
              <span>Nearly fainted or felt close to it</span>
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={chestPressure}
                onChange={(e) => setChestPressure(e.target.checked)}
              />
              <span>Chest pressure or tightness</span>
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={usedSubstances}
                onChange={(e) => setUsedSubstances(e.target.checked)}
              />
              <span>Used anything today (no judgment)</span>
            </label>
          </div>
        </div>

        <div className="flex gap-2">
          <Button onClick={handleSubmit} disabled={submitting}>
            {submitting ? "Running check..." : "Run Check-In"}
          </Button>
        </div>
      </Card>

      {risk && <RiskPanel score={risk.score} level={risk.level} />}
    </div>
  );
}
