import type { ButtonHTMLAttributes } from "react";
import clsx from "clsx";

export function Button({
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      className={clsx(
        "inline-flex items-center justify-center rounded-lg px-4 py-2 text-sm font-medium",
        "bg-sgAccent text-black hover:bg-emerald-400 disabled:opacity-60",
        className
      )}
      {...props}
    />
  );
}
