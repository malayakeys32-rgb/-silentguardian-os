import type { ReactNode } from "react";
import clsx from "clsx";

export function Card({
  children,
  className
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={clsx(
        "rounded-xl bg-sgCard border border-white/5 shadow-lg p-4",
        className
      )}
    >
      {children}
    </div>
  );
}
