"use client";

import type { ChangeEvent } from "react";

type Props = {
  label: string;
  value: number;
  onChange: (v: number) => void;
  min?: number;
  max?: number;
};

export function Slider({ label, value, onChange, min = 0, max = 3 }: Props) {
  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    onChange(Number(e.target.value));
  };

  const labels = ["None", "Mild", "Moderate", "Severe"];

  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs text-sgMuted">
        <span>{label}</span>
        <span>{labels[value] ?? value}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={handleChange}
        className="w-full accent-sgAccent"
      />
      <div className="flex justify-between text-[10px] text-sgMuted">
        {labels.map((l, i) => (
          <span key={l} className={i === value ? "text-sgAccent" : ""}>
            {l}
          </span>
        ))}
      </div>
    </div>
  );
}
