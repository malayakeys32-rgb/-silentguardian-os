import { prisma } from "@/lib/prisma";

export async function getOrCreateDevice(deviceId: string) {
  let device = await prisma.userDevice.findUnique({ where: { deviceId } });
  if (!device) {
    device = await prisma.userDevice.create({ data: { deviceId } });
  }
  return device;
}

export function getDeviceIdFromRequest(req: Request): string {
  const header = req.headers.get("x-device-id");
  return header ?? "demo-device";
}
