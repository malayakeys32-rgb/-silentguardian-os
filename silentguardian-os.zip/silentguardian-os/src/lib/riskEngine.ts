export type RiskResult = {
  score: number;
  level: "LOW" | "WARN" | "DANGER";
};

export function computeRisk(input: {
  shortnessOfBreath: number;
  fatigueLevel: number;
  canLieFlat: boolean;
  coughWorse: boolean;
  nearFaint: boolean;
  chestPressure: boolean;
  usedSubstances: boolean;
}): RiskResult {
  let score = 0;

  score += input.shortnessOfBreath * 10;
  score += input.fatigueLevel * 8;

  if (!input.canLieFlat) score += 15;
  if (input.coughWorse) score += 10;
  if (input.nearFaint) score += 20;
  if (input.chestPressure) score += 25;
  if (input.usedSubstances) score += 10;

  let level: RiskResult["level"] = "LOW";
  if (score >= 40 && score < 60) level = "WARN";
  if (score >= 60) level = "DANGER";

  return { score, level };
}

export function riskLabel(level: RiskResult["level"]): string {
  if (level === "LOW") return "Stable pattern. Keep checking in.";
  if (level === "WARN") return "Concerning pattern. Consider calling your care team.";
  return "High-risk pattern. Please contact your care team or go to the ER. You deserve help.";
}
