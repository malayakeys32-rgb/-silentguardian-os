export type DeviceContext = {
  deviceId: string;
};
